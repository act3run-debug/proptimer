# RepoMapper MCP — инструкция агенту в новой сессии

RepoMapper (pdavis68/RepoMapper) строит карту репозитория: tree-sitter извлекает
сигнатуры def/class, граф «определение→ссылки» ранжируется персональным PageRank,
вывод — дерево сигнатур в токен-бюджет. MCP-сервер (stdio), 2 инструмента:
`repo_map` и `search_identifiers`. Цель: понимать чужой код без чтения целиком.

## 1. Подъём (один раз за сессию, ~1 мин)
```bash
tar -xzf repomap-mcp-kit.tar.gz        # если комплект пришёл архивом
bash repomap-kit/bootstrap-repomap.sh  # venv с пин-версиями; идемпотентен
```
Состав комплекта: `RepoMapper-src/` (исходники сервера, офлайн-копия),
`mcp-call.mjs` (универсальный MCP-клиент, stdio JSON-RPC), `repomap-notes.md`
(полный конспект ревью и граблей), `bootstrap-repomap.sh`.

## 2. Проверка
```bash
KIT=$(pwd)/repomap-kit
SRV="$KIT/RepoMapper-src/.venv/bin/python $KIT/RepoMapper-src/repomap_server.py"
node "$KIT/mcp-call.mjs" list --server "$SRV"   # ожидать: repo_map, search_identifiers
```

## 3. Применение
```bash
ROOT=$(cd /путь/к/изучаемому/репо && pwd)
node "$KIT/mcp-call.mjs" call repo_map \
  "{\"project_root\":\"$ROOT\",\"token_limit\":4000}" --server "$SRV"
# большой репо — сузить скан (иначе сервер ползёт по всему корню, включая мусор):
#   "{\"project_root\":\"$ROOT\",\"other_files\":[\"src/a.py\",\"lib/b.js\"],\"token_limit\":4000}"
node "$KIT/mcp-call.mjs" call search_identifiers \
  "{\"project_root\":\"$ROOT\",\"identifier\":\"имя_идентификатора\"}" --server "$SRV"
```
Рабочий цикл: `repo_map` → выбрать файлы из карты → читать точечно.
Заодно: `chat_files`/`mentioned_files`/`mentioned_idents`.boost-ят ранги —
передавай файлы текущей задачи, карта станет релевантнее.
CLI-альтернатива без MCP:
`"$KIT/RepoMapper-src/.venv/bin/python" "$KIT/RepoMapper-src/repomap.py" . --root "$ROOT" --map-tokens 4000`
(обязательны позиционные paths или --other-files, иначе карта пустая).

## 4. Грабли (уже оплачены отладкой — не повторять)
- НЕ обновлять зависимости в venv: версии строго из uv.lock автора
  (tree-sitter 0.25.1, fastmcp 2.11.3, mcp 1.13.1, pydantic 2.11.7…);
  свежие tree-sitter/fastmcp/pydantic ломают сервер импортами.
- Карта пустая при nonzero-файлах → протухший кэш тегов:
  `rm -rf "$ROOT/.repomap.tags.cache.v*"` (`--force-refresh` его НЕ чистит).
- Литерал `/home/user` внутри JSON-аргументов не писать: харнесс песочницы
  переписывает его на shell-выражение и JSON ломается; пути только через $ROOT/$(pwd).
- Сервер живёт в пределах ОДНОГО вызова bash (демоны между вызовами не живут):
  цепочки вызовов группировать в один вызов или пользоваться CLI.
- token_limit — бюджет карты в токенах; 2000–8000 хватает на средний репозиторий.
