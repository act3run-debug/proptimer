#!/bin/bash
# Идемпотентный подъём RepoMapper MCP в новой песочнице (~30-60 с).
set -e
KIT="$(cd "$(dirname "$0")" && pwd)"
SRC="$KIT/RepoMapper-src"
if [ -x "$SRC/.venv/bin/python" ]; then echo "venv уже есть: $SRC/.venv"; exit 0; fi
cd "$SRC"
python3 -m venv .venv
.venv/bin/pip install -q --upgrade pip
# ВЕРСИИ СТРОГО из uv.lock автора — свежие tree-sitter/fastmcp/pydantic ломают код:
.venv/bin/pip install -q "tree-sitter==0.25.1" "tree-sitter-language-pack==0.9.0" \
  "grep-ast==0.9.0" "tiktoken==0.11.0" "networkx==3.5" "diskcache==5.6.3" \
  "pygments==2.19.2" "fastmcp==2.11.3" "mcp==1.13.1" "pydantic==2.11.7"
rm -rf .repomap.tags.cache.v*
echo "Готово. Сервер: $SRC/.venv/bin/python $SRC/repomap_server.py"
