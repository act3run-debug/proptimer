#!/usr/bin/env node
/**
 * mcp-call.mjs — УНИВЕРСАЛЬНЫЙ MCP-клиент (stdio, JSON-RPC 2.0). Без зависимостей.
 * Поднимает любой локальный MCP-сервер, делает initialize → выполняет вызовы → гасит сервер.
 * Это мост: внешние MCP-инструменты становятся доступны агенту через bash.
 *
 * Использование:
 *   mcp-call.mjs list  --server "npx @playwright/mcp@latest --headless"
 *   mcp-call.mjs call  <tool> '<json-args>' --server "<команда сервера>"
 *   mcp-call.mjs batch <file.jsonl>        --server "<команда сервера>"
 *        jsonl-строки: {"tool":"имя","args":{...}}
 *   Опции: --timeout=мс (90000), --verbose (stderr сервера в консоль)
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';

const argv = process.argv.slice(2);
const opts = {}; const pos = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a.startsWith('--')) {
    const [k, ...v] = a.slice(2).split('=');
    if (v.length) opts[k] = v.join('=');
    else if (argv[i + 1] !== undefined && !argv[i + 1].startsWith('--')) opts[k] = argv[++i];
    else opts[k] = true;
  } else pos.push(a);
}
const mode = pos[0];
const SERVER = typeof opts.server === 'string' ? opts.server : null;
const TIMEOUT = Number(opts.timeout || 90000);
if (!SERVER) { console.error('нужна --server "<команда запуска MCP-сервера>"'); process.exit(1); }

const child = spawn(SERVER, { shell: true, stdio: ['pipe', 'pipe', 'pipe'], env: process.env });
const pending = new Map();
let buf = '', nextId = 1, dead = false;

const send = o => { if (!dead) child.stdin.write(JSON.stringify(o) + '\n'); };
const req = (method, params) => new Promise((res, rej) => {
  const id = nextId++;
  const t = setTimeout(() => rej(new Error(`таймаут ${TIMEOUT}мс на ${method}`)), TIMEOUT);
  pending.set(id, m => { clearTimeout(t); res(m); });
  send({ jsonrpc: '2.0', id, method, params });
});
const notify = (method, params) => send({ jsonrpc: '2.0', method, params });

child.stdout.on('data', d => {
  buf += d.toString();
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
    if (!line) continue;
    let m; try { m = JSON.parse(line); } catch { continue; }
    if (m.id != null && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
    else if (m.id != null && m.method) send({ jsonrpc: '2.0', id: m.id, result: {} }); // ping и т.п.
  }
});
child.stderr.on('data', d => { if (opts.verbose) process.stderr.write('[server] ' + d); });
child.on('exit', () => { dead = true; });

const die = (msg) => { console.error('ОШИБКА: ' + msg); try { child.kill('SIGKILL'); } catch {} process.exit(1); };

function showResult(r) {
  if (r.error) return { error: r.error };
  const c = r.result?.content;
  if (Array.isArray(c)) {
    const texts = c.filter(x => x.type === 'text').map(x => x.text);
    return { text: texts.join('\n'), structured: r.result.structuredContent ?? undefined, isError: r.result.isError ?? false };
  }
  return { raw: r.result };
}

(async () => {
  const init = await req('initialize', {
    protocolVersion: '2025-06-18',
    capabilities: {},
    clientInfo: { name: 'qwen-bridge', version: '1.0' },
  });
  if (init.error) die('initialize: ' + JSON.stringify(init.error));
  notify('notifications/initialized', {});
  const serverName = init.result?.serverInfo?.name + ' ' + (init.result?.serverInfo?.version || '');

  if (mode === 'list') {
    const r = await req('tools/list', {});
    if (r.error) die(JSON.stringify(r.error));
    console.log(`# сервер: ${serverName}`);
    console.log(JSON.stringify(r.result.tools.map(t => ({
      name: t.name,
      description: (t.description || '').slice(0, 200),
      args: Object.entries(t.inputSchema?.properties || {}).map(([k, v]) => `${k}${t.inputSchema.required?.includes(k) ? '*' : ''}: ${v.type}`),
    })), null, 2));
  } else if (mode === 'call') {
    const name = pos[1]; let args = {};
    if (pos[2]) { try { args = JSON.parse(pos[2]); } catch (e) { die('невалидный JSON аргументов'); } }
    const r = await req('tools/call', { name, arguments: args });
    console.log(JSON.stringify(showResult(r), null, 2));
  } else if (mode === 'batch') {
    const lines = fs.readFileSync(pos[1], 'utf8').split('\n').map(s => s.trim()).filter(Boolean);
    const out = [];
    for (const line of lines) {
      const spec = JSON.parse(line);
      const started = Date.now();
      const r = await req('tools/call', { name: spec.tool, arguments: spec.args || {} });
      out.push({ tool: spec.tool, ms: Date.now() - started, ...showResult(r) });
    }
    console.log(JSON.stringify(out, null, 2));
  } else die('режим: list | call | batch');

  try { child.kill('SIGTERM'); } catch {}
  process.exit(0);
})().catch(e => die(e.message));
