# RepoMapper (pdavis68/RepoMapper) — конспект ревью и запуска в песочнице

## Что внутри (прочитано всё, ~1300 строк)
- `repomap.py` — CLI (аргументы: paths, --root, --map-tokens, --chat-files,
  --other-files, --mentioned-files/--mentioned-idents, --force-refresh, --verbose).
  БЕЗ явных paths/--other-files карта пустая (в отличие от MCP-сервера).
- `repomap_class.py` — ядро: tree-sitter-теги (def/reference) через grep_ast +
  tree-sitter-language-pack и .scm-запросы из `queries/` (33 языка);
  граф (файл,идент)->(файл,идент); персональный PageRank (networkx, alpha=0.85,
  personalization = бусты chat_files > mentioned > other); render_tree — дерево
  сигнатур в токен-бюджет (tiktoken) бинарным поиском по числу тегов;
  diskcache-кэш тегов `.repomap.tags.cache.v1` (keyed by mtime).
- `repomap_server.py` — fastmcp-сервер, 2 инструмента: `repo_map`, `search_identifiers`.
  Сканирует root ЦЕЛИКОМ (кроме dot-директорий, node_modules, __pycache__, venv),
  если other_files не заданы — может уехать в мусор (ms-playwright и т.п.).
- `importance.py` — эвристика «важных файлов» (README, package.json, Dockerfile…),
  всегда попадают в карту. `scm.py` — язык → .scm-файл запросов.
- Родословная: порт repo-map из aider.

## Рабочий рецепт в песочнице
```bash
cd ~/repos/RepoMapper
python3 -m venv .venv
.venv/bin/pip install "tree-sitter==0.25.1" "tree-sitter-language-pack==0.9.0" \
  "grep-ast==0.9.0" "tiktoken==0.11.0" "networkx==3.5" "diskcache==5.6.3" \
  "pygments==2.19.2" "fastmcp==2.11.3" "mcp==1.13.1" "pydantic==2.11.7"   # = uv.lock
# CLI:
.venv/bin/python repomap.py . --root . --map-tokens 1000
# MCP через универсальный клиент:
node ~/browser-lab/mcp-call.mjs call repo_map "{\"project_root\":\"$ROOT\",\"token_limit\":800}" \
  --server "~/repos/RepoMapper/.venv/bin/python ~/repos/RepoMapper/repomap_server.py"
```

## Грабли (все найдены на себе)
1. Свежие tree-sitter/fastmcp/mcp/pydantic ломают код → ставить СТРОГО версии из uv.lock, в venv.
2. Битый кэш тегов после неудачных прогонов даёт тихую пустую карту; --force-refresh
   чистит только кэш КАРТ, не тегов → `rm -rf .repomap.tags.cache.v*`.
3. CLI без paths/--other-files = пустая карта; сервер без other_files сканирует весь root.
4. CLI печатает кортеж (map, report) — рассинхрон CLI с API класса (косметика).
5. Харнесс песочницы переписывает литерал `/home/user` в командах на shell-выражение —
   внутри JSON-аргументов MCP пути собирать через ROOT=$(pwd), не литералом.

## Зачем нам
Дешёвая «разведка кода» перед чтением файлов: карта → выбор файлов → точечное чтение.
Интеграция: инструмент tier-A сабагентов (worker вызывает CLI) и мой собственный
первый шаг при изучении чужого репозитория.
